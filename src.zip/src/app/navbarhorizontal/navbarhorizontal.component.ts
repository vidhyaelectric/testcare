import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbarhorizontal',
  templateUrl: './navbarhorizontal.component.html',
  styleUrls: ['./navbarhorizontal.component.css']
})
export class NavbarhorizontalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
